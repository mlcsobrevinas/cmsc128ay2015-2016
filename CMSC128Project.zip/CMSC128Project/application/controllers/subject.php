<?php

class subject extends CI_Controller {
	

	function index()
	{
	}
	function LoadAddSubject(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('addsubject');
	}//end of LoadAddSubject function
	function LoadDeleteSubject(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('deletesubject');
	}//end of LoadAddSubject function
	
	function AddSubject(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('subject_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('subject_name', 'Subject Name', 'required');
		$this->form_validation->set_rules('subject_desc', 'Subject Description', 'required');
		$this->form_validation->set_rules('subject_unit', 'Subject Unit', 'required');
		$this->form_validation->set_rules('subject_type', 'Subject Type', 'required');
		$this->form_validation->set_rules('subject_teacher', 'Subject Teacher', 'required');
		$this->form_validation->set_rules('time_start', 'Time Start', 'required');
		$this->form_validation->set_rules('time_end', 'Time End', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('addsubject');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			//GET USER INPUT
			$subject_data = array(
							'Subject_type' => $this->input->post('subject_type'),
							'Subject_unit' => $this->input->post('subject_unit'),
							'Subject_name' => $this->input->post('subject_name'),
							'Time_slot_start' => $this->input->post('time_start'),
							'Description' => $this->input->post('subject_desc'),
							'Emp_num' => $this->input->post('subject_teacher'),
							'Time_slot_end' => $this->input->post('time_end')
			);	
			//CALL ADD SUBJECT FUNCTION
			$result = $this->subject_model->AddSubjectModel($subject_data);
			//IF SUCCESSFUL ADDING SUBJECT GO TO HOME
			if($result){
				$this->load->view('formsuccess');
			}
		}
			
				
	}//end of add subject function
	
	function DeleteSubject(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('subject_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('name', 'Subject Name', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('deletesubject');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			
			$subject_name = $this->input->post('name');
			//CALL ADD SUBJECT FUNCTION
			$result = $this->subject_model->DeleteSubjectModel($subject_name);
			//IF SUCCESSFUL ADDING SUBJECT GO TO HOME
			if($result){
				$this->load->view('formsuccess');
			}
		}
			
				
	}//end of delete subject function
}

?>