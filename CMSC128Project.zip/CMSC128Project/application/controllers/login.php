<?php

class login extends CI_Controller {
	

	function index()
	{

		//load helper and libraries
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->library('session');
		
		$loginVerify = $this->session->userdata('logged_in');
		
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		//NOT SUCCESSFUL
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('loginpage');
		}
		//SUCCESSFUL
		else
		{
			//LOAD MODEL FOR DATABASE
			$this->load->model('account');
			//GET USER INPUT
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			
			//CALL LOGIN FUNCTION
			$result = $this->account->login($username, $password);
			//SUCCESSFUL LOG-IN
			if($result)
			{
				$this->load->view('formsuccess');
				//START SESSION
				
				$data = array(
                   'username'  => $username,
                   'password'  => $password,
                   'logged_in' => TRUE
				);

				$this->session->set_userdata($data);
			}
			//NOT SUCCESSFUL: RETURN TO LOG-IN
			 else
			{
				$this->load->view('loginpage');
			}
		}
			
	}//end of index function
	
	public function logout(){
		$this->load->library('session');
        $this->session->sess_destroy();
		$this->load->helper(array('form', 'url'));
		$this->load->view('loginpage');
    }//end of log-out function
}

?>