<?php

class attendance extends CI_Controller {
	
	function index()
	{
	}

	function LoadAttendance(){
		$this->load->helper(array('form', 'url'));
			$this->load->view('attendance_view');
	}
	function LoadDeleteAttendance(){
		$this->load->helper(array('form', 'url'));
			$this->load->view('attendance_view2');
	}
	function AddAttendance()
	{
		//load helper and libraries
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('attendance_model');
		
		$this->form_validation->set_rules('stud_id', 'Student ID', 'required');
		$this->form_validation->set_rules('grading_period', 'Grading Period', 'required');
		$this->form_validation->set_rules('batch_id', 'Batch ID', 'required');
		$this->form_validation->set_rules('days_tardy', 'Days Tardy', 'required');
		$this->form_validation->set_rules('days_present', 'Days Present', 'required');
		$this->form_validation->set_rules('days_total', 'Total Number of Days', 'required');
		//NOT SUCCESSFUL
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('attendance_view');
		}
		//SUCCESSFUL
		else
		{
			//GET USER INPUT
			$data = array(
							'grading_period' => $this->input->post('grading_period'),
							'batch_id' => $this->input->post('batch_id'),
							'student_days_tardy' => $this->input->post('days_tardy'),
							'student_days_present' => $this->input->post('days_present'),
							'school_days' => $this->input->post('days_total'),
							'student_id' => $this->input->post('stud_id')
			);	
			//CALL ADD STUDENT FUNCTION
			$result = $this->attendance_model->addAttendance($data);
			//IF SUCCESSFUL ADDING SUBJECT GO TO HOME
			if($result){
				$this->load->view('formsuccess');
			}
		}
			
	}//end of index function

	function DeleteAttendance(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('attendance_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('stud_id', 'Student ID', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('attendance_view2');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			
			$student_id = $this->input->post('stud_id');
			//CALL ADD STUDENT FUNCTION
			$result = $this->attendance_model->DeleteAttendance($student_id);
			//IF SUCCESSFUL ADDING STUDENT GO TO HOME
			if($result){
				$this->load->view('formsuccess');
			}
		}
			
				
	}//end of delete student function
}

?>