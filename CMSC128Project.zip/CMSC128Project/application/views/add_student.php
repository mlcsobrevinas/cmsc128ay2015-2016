<html>
<head>
<title>Add-Student</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('student/AddStudent'); ?>

<h5>Student Name:</h5>
<input type="text" name="stud_name" id = "stud_name" value="" size="50" />
<h5>Student Address:</h5>
<input type="text" name="stud_address" id = "stud_address" value="" size="50" />
<h5>Student Nationality:</h5>
<input type="text" name="stud_nationality" id = "stud_nationality" value="" size="50" />
<h5>Student Sex:</h5>
<input type="text" name="stud_sex" id = "stud_sex" value="" size="50" />
<h5>Student Birthdate:</h5>
<input type="text" name="stud_bday" id = "stud_bday" value="" size="50" />
<h5>Student Status:</h5>
<input type="text" name="stud_status" id = "stud_status" value="" size="50" />
<h5>Student Curriculum:</h5>
<input type="text" name="stud_curri" id = "stud_curri" value="" size="50" />

<div><input type="submit" value="Add Student" /></div>

</body>
</html>
