<html>
<head>
<title>Add-User</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('form'); ?>


	<h5>Employee Number</h5>
	<input type="text" name="emp_num" id = "emp_num" value="" size="50" />

	<h5>Employee Name</h5>
	<input type="text" name="emp_name" id = "emp_name" value="" size="50" />

	<h5>Employee Designation</h5>
	<input type="text" name="emp_desig" id = "emp_desig" value="" size="50" />


	<div><input type="submit" value="Add User" /></div>
	</form>
</body>
</html>
