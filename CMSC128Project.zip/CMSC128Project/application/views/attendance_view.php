<html>
<head>
<title>Add-Student</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('attendance/addAttendance'); ?>

<h5>Student ID:</h5>
<input type="text" name="stud_id" id = "stud_id" value="" size="50" />

<h5>Batch ID:</h5>
<input type="text" name="batch_id" id = "batch_id" value="" size="50" />

<h5>Grading Period:</h5>
<input type="text" name="grading_period" id = "grading_period" value="" size="50" />

<h5>Number of Days Present:</h5>
<input type="text" name="days_present" id = "days_present" value="" size="50" />

<h5>Number of Days Tardy:</h5>
<input type="text" name="days_tardy" id = "days_tardy" value="" size="50" />

<h5>Total Number of Days:</h5>
<input type="text" name="days_total" id = "days_total" value="" size="50" />

<div><input type="submit" value="Add Attendance" /></div>

</body>
</html>
