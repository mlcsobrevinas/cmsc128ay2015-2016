<html>
<head>
<title>Delete-Subject</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('subject/DeleteSubject'); ?>

<h5>Subject Title</h5>
<input type="text" name="name" id = "name" value="" size="50" />

<div><input type="submit" value="Delete Subject" /></div>

</body>
</html>
