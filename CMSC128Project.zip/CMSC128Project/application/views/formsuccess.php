<html>
<head>
<title>My Form</title>
</head>
<body>

<h3>Your have successfully logged-in!</h3>
<b>Mary</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("login/logout");?>'">Log Out</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subject/LoadAddSubject");?>'">GO TO ADD SUBJECT</button>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subject/LoadDeleteSubject");?>'">GO TO DELETE SUBJECT</button>
<br>
<br>
<b>Xavier</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("student/LoadAddStudent");?>'">ADD STUDENT</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("student/LoadDeleteStudent");?>'">DELETE STUDENT</button>
<br>
<br>
<b>Paolo</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("attendance/LoadAttendance");?>'">ADD attendance</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("attendance/LoadDeleteAttendance");?>'">DELETE attendance</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("student/LoadAddStudent");?>'">EDIT attendance</button>
<br>
<br>
<b>YEL</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("student/LoadAddStudent");?>'">EDIT USER</button>

</body>
</html>