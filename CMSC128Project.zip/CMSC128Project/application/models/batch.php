<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Batch extends CI_Model {
	//GET ADVISER OF THAT BATCH
	
	//GET STUDENTS OF THAT BATCH
	
     
	 
}
