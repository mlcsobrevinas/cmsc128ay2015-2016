<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subject_Teacher extends CI_Model {
	 
}
