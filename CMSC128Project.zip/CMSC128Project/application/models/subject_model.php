<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class subject_model extends CI_Model {
	public function __construct()
    {
        parent::__construct();
        //$this->load->helper('url');     
    }   

	//Get Subject ID
	 function getSubjectID($subname){
		$this->load->database();
		$query = "SELECT Subject_id FROM subject WHERE Subject_name LIKE '".$subname."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }

	//ADD SUBJECT BY ADMIN TO DATABASE
	function AddSubjectModel($subject_data){//FROM POST
		$this->load->database();
		$this->db->insert('subject', $subject_data);
		return TRUE;
	}
	   
	//DELETE SUBJECT BY ADMIN FROM DATABASE
	function DeleteSubjectModel($name){
		$this->load->database();
		$query = "DELETE FROM subject WHERE Subject_name LIKE '".$name."'"; 
		$this->db->query($query);
		return TRUE;
	}
	//ADD SUBJECT TO STUDENT
	function AddSubjectToStudent($subject_id, $student_id){
		$this->load->database();
		$query = "INSERT INTO student_subject reference(Subject_id, Student_id)VALUES('".$subject_id."','".$student_id."')"; 
		$queryresults = $this->db->query($query)->result();
	}
	
	 
}
