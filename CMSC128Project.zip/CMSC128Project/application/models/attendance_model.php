<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class attendance_model extends CI_Model {


	//ADD ATTENDANCE 
	function addAttendance($data){
		$this->load->database();
     	$this->db->insert('attendance', $data);
		return TRUE;
	}
	//DELETE ATTENDANCE
	function deleteAttendance($student_id){
		$this->load->database();
		$query = "DELETE FROM attendance WHERE student_id = '".$student_id."'"; //query for i
		$this->db->query($query);
		return TRUE;
	}
    //EDIT ATTENDANCE 
	 
}
