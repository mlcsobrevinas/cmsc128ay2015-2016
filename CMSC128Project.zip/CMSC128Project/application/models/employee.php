<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Employee extends CI_Model {
	//ADD USER
	//DELETE USER
    //EDIT USER
	
	//GET EMPLOYEE_ID OF AN EMPLOYEE
	 function getEmployeeID($emp_name){
		$this->load->database();
		$query = "SELECT Studet_id FROM students WHERE name LIKE '".$emp_name."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }
	 //GET ROLE OF AN EMPLOYEE
	 
	 //if admin
	  function getAdminRole($emp_id){
		$this->load->database();
		$query = "SELECT Admin_Flag FROM students WHERE name LIKE '".$emp_name."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }
	 //if adviser
	  function getAdviserRole($emp_id){
		$this->load->database();
		$query = "SELECT Adviser_Flag FROM students WHERE name LIKE '".$emp_name."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }
	 
	 //if subject teacher
	  function getSubRole($emp_id){
		$this->load->database();
		$query = "SELECT Subj_teacher_flag FROM students WHERE name LIKE '".$emp_name."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }
	 
}
