<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subject_Grade extends CI_Model {
	//ADD SUBJECT_GRADE TO STUDENT
	//EDIT SUBJECT GRADE TO STUDENT
     
}

