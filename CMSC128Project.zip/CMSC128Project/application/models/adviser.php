<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Adviser extends CI_Model {
	
	 
}
